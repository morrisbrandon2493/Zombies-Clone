package com.mygdx.game.Interfaces;
import com.badlogic.gdx.math.Rectangle;

public class HitBox extends Rectangle
{
	private static final long serialVersionUID = 3997283747592551763L;
	
	public HitBox(float x, float y, float width, float height)
	{
		super(x,y,width,height);
	}
	
}
