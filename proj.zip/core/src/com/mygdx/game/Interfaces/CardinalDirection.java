package com.mygdx.game.Interfaces;

public enum CardinalDirection {
NORTH, NORTHEAST, EAST, SOUTHEAST, SOUTH, SOUTHWEST, WEST, NORTHWEST
}
