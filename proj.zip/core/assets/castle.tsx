<?xml version="1.0" encoding="UTF-8"?>
<tileset name="entities1" tilewidth="16" tileheight="16" tilecount="1794" columns="46">
 <image source="castle_tile_set_1.png" trans="000000" width="740" height="632"/>
</tileset>
