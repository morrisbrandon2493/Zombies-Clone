<?xml version="1.0" encoding="UTF-8"?>
<tileset name="CollisionSquare" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="collisionSquare.png" trans="000000" width="16" height="16"/>
</tileset>
