<?xml version="1.0" encoding="UTF-8"?>
<tileset name="entities1" tilewidth="16" tileheight="16" tilecount="1792" columns="32">
 <image source="inside_pub_by_candacis.png" trans="000000" width="512" height="896"/>
</tileset>
