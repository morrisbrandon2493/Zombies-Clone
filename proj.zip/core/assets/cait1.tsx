<?xml version="1.0" encoding="UTF-8"?>
<tileset name="test2" tilewidth="16" tileheight="16" tilecount="960" columns="32">
 <image source="caitzombie1wall.png" trans="000000" width="512" height="480"/>
 <terraintypes>
  <terrain name="walls" tile="430"/>
 </terraintypes>
 <tile id="332" terrain=",,,0"/>
 <tile id="333" terrain=",,0,"/>
 <tile id="334" terrain=",0,0,0"/>
 <tile id="335" terrain="0,,0,0"/>
 <tile id="364" terrain=",0,,"/>
 <tile id="365" terrain="0,,,"/>
 <tile id="366" terrain="0,0,,0"/>
 <tile id="367" terrain="0,0,0,"/>
 <tile id="396" terrain=",,,0"/>
 <tile id="397" terrain=",,0,0"/>
 <tile id="398" terrain=",,0,0"/>
 <tile id="399" terrain=",,0,"/>
 <tile id="428" terrain=",0,,0"/>
 <tile id="429" terrain="0,0,0,0"/>
 <tile id="430" terrain="0,0,0,0"/>
 <tile id="431" terrain="0,,0,"/>
 <tile id="460" terrain=",0,,0"/>
 <tile id="461" terrain="0,0,0,0"/>
 <tile id="462" terrain="0,0,0,0"/>
 <tile id="463" terrain="0,,0,"/>
 <tile id="492" terrain=",0,,"/>
 <tile id="493" terrain="0,0,,"/>
 <tile id="494" terrain="0,0,,"/>
 <tile id="495" terrain="0,,,"/>
</tileset>
